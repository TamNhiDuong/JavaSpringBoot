package com.example.friendList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FriendListApplication {

	public static void main(String[] args) {
		SpringApplication.run(FriendListApplication.class, args);
	}

}
