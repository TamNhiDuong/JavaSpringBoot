package com.example.friendList.domain;

public class Friend {
	private String name;
	
	public Friend(String name) {
		// TODO Auto-generated constructor stub
		this.name = name;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.name;
	}
}
